#include "arduino.h"
#include "Motor.h"

const uint8_t dirA = 12;
const uint8_t dirB = 13;
const uint8_t brA = 9;
const uint8_t brB = 8;
const uint8_t pwmA = 3;
const uint8_t pwmB = 11;


Motor::Motor() {} // setup motor class

void Motor::SETUP() { //setup function

    pinMode(dirA, OUTPUT);
    pinMode(dirB, OUTPUT);
    pinMode(brA, OUTPUT);
    pinMode(brB, OUTPUT);

}

void Motor::forwards() {  //function to move buggy forward 

    digitalWrite(dirA, HIGH);
    digitalWrite(brA, LOW);
    analogWrite(pwmA, 255);

    digitalWrite(dirB, LOW);
    digitalWrite(brB, LOW);
    analogWrite(pwmB, 255);

}

void backwards() {  // function to move buggy backwards

    digitalWrite(dirA, LOW);
    digitalWrite(brA, LOW);
    analogWrite(pwmA, 255);

    digitalWrite(dirB, HIGH);
    digitalWrite(brB, LOW);
    analogWrite(pwmB, 255);

}

void halt() {  // function to stop buggy from moving
    digitalWrite(brA, HIGH);

    digitalWrite(brB, HIGH);

}

void left90() {  // function to rotate buggy to left

    digitalWrite(dirA, HIGH);
    digitalWrite(brA, LOW);
    analogWrite(pwmA, 255);

    digitalWrite(dirB, HIGH);
    digitalWrite(brB, LOW);
    analogWrite(pwmB, 255);

    delay(1000);

    halt()
}


void right90() {  //function to rotate buggy to the right

    digitalWrite(dirA, LOW);
    digitalWrite(brA, LOW);
    analogWrite(pwmA, 255);

    digitalWrite(dirB, LOW);
    digitalWrite(brB, LOW);
    analogWrite(pwmB, 255);

    delay(1000);

    halt()

}


Motor Motor = Motor();