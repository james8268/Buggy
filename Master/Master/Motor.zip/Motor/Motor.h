#ifndef Motor_h
#define Motor_h

class Motor
{
public:
    Motor();
    void SETUP();
    void forwards();
    void backwards();
    void left90();
    void right90();
    void halt();


};

#endif
